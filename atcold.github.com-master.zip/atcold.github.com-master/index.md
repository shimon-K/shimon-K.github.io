---
layout: page
---

<span style="display:block; margin-top:-30px;">
![My face](https://avatars.githubusercontent.com/u/2119355?v=4)
</span>


# About me

Musician, math lover, cook, and dancer who is currently working as an Assistant Teaching Professor of Computer Science at Courant Institute of Mathematical Sciences, under the supervision of professors Kyunghyun Cho and Yann LeCun.

Check out
<a style="color:#8dd3c7" href="/didactics.html">Didactics</a>,
<a style="color:#8dd3c7" href="/twitter.html">Twitter archive</a>, and
<a style="color:#8dd3c7" href="/youtube.html">YouTube archive</a>.
