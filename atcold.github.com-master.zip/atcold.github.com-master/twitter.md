---
layout: page
title: Twitter archive
---


<p class="warning">Under construction.</p>

This page acts as a directory for major posts I created on [Twitter](https://twitter.com/alfcnz), sorted by theme by inverse chronological order, or by inverse chronological order by theme.


## Themes

- NYU Deep Learning course
- Life & philosophy
- Unix utilities
- Productivity & organisation


## Inverse chronological order

- 2021
- 2020
- 2019
- 2018