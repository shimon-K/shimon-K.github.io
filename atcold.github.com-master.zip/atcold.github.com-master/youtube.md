---
layout: page
title: YouTube archive
---


<p class="warning">Under construction.</p>

This page acts as a directory for major video playlists published on [YouTube](https://www.youtube.com/channel/UCupQLyNchb9-2Z5lmUOIijw), sorted by theme by inverse chronological order.